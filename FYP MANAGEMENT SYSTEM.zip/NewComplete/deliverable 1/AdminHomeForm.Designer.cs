﻿namespace deliverable_1
{
    partial class AdminHomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_main2 = new System.Windows.Forms.Panel();
            this.panel_cover = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.MeetscheduleButton = new System.Windows.Forms.Button();
            this.MarksButton = new System.Windows.Forms.Button();
            this.ProfileButton = new System.Windows.Forms.Button();
            this.panel_slide = new System.Windows.Forms.Panel();
            this.panel_AnnounceSubmenu = new System.Windows.Forms.Panel();
            this.button_viewall = new System.Windows.Forms.Button();
            this.button_makeannouncement = new System.Windows.Forms.Button();
            this.button_Announcements = new System.Windows.Forms.Button();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.panelmngstudentsubmenu = new System.Windows.Forms.Panel();
            this.button_removeStudent = new System.Windows.Forms.Button();
            this.button_addstudent = new System.Windows.Forms.Button();
            this.Managestu_Button = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel_home = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_LOGOUT = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.panel_main2.SuspendLayout();
            this.panel_cover.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel_slide.SuspendLayout();
            this.panel_AnnounceSubmenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panelmngstudentsubmenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel_home.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_main2
            // 
            this.panel_main2.Controls.Add(this.panel_cover);
            this.panel_main2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel_main2.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel_main2.Location = new System.Drawing.Point(213, 0);
            this.panel_main2.Name = "panel_main2";
            this.panel_main2.Size = new System.Drawing.Size(822, 504);
            this.panel_main2.TabIndex = 7;
            // 
            // panel_cover
            // 
            this.panel_cover.BackColor = System.Drawing.Color.SkyBlue;
            this.panel_cover.Controls.Add(this.panel3);
            this.panel_cover.Controls.Add(this.panel2);
            this.panel_cover.Controls.Add(this.pictureBox2);
            this.panel_cover.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_cover.Location = new System.Drawing.Point(0, 0);
            this.panel_cover.Name = "panel_cover";
            this.panel_cover.Size = new System.Drawing.Size(822, 504);
            this.panel_cover.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Navy;
            this.panel3.Controls.Add(this.button_LOGOUT);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 352);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(822, 152);
            this.panel3.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Navy;
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(822, 118);
            this.panel2.TabIndex = 1;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox3.BackColor = System.Drawing.Color.Navy;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox3.Image = global::deliverable_1.Properties.Resources.pngwing_com;
            this.pictureBox3.Location = new System.Drawing.Point(259, 33);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(253, 58);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.Image = global::deliverable_1.Properties.Resources.FYP;
            this.pictureBox2.Location = new System.Drawing.Point(164, 80);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(421, 314);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // MeetscheduleButton
            // 
            this.MeetscheduleButton.BackColor = System.Drawing.Color.Navy;
            this.MeetscheduleButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.MeetscheduleButton.FlatAppearance.BorderSize = 0;
            this.MeetscheduleButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MeetscheduleButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MeetscheduleButton.ForeColor = System.Drawing.Color.White;
            this.MeetscheduleButton.Location = new System.Drawing.Point(0, 252);
            this.MeetscheduleButton.Name = "MeetscheduleButton";
            this.MeetscheduleButton.Size = new System.Drawing.Size(196, 42);
            this.MeetscheduleButton.TabIndex = 7;
            this.MeetscheduleButton.Text = "     Meetings Schedule";
            this.MeetscheduleButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.MeetscheduleButton.UseVisualStyleBackColor = true;
            this.MeetscheduleButton.Click += new System.EventHandler(this.MeetscheduleButton_Click);
            // 
            // MarksButton
            // 
            this.MarksButton.BackColor = System.Drawing.Color.Navy;
            this.MarksButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.MarksButton.FlatAppearance.BorderSize = 0;
            this.MarksButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MarksButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MarksButton.ForeColor = System.Drawing.Color.White;
            this.MarksButton.Location = new System.Drawing.Point(0, 210);
            this.MarksButton.Name = "MarksButton";
            this.MarksButton.Size = new System.Drawing.Size(196, 42);
            this.MarksButton.TabIndex = 6;
            this.MarksButton.Text = "     Marks";
            this.MarksButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.MarksButton.UseVisualStyleBackColor = true;
            this.MarksButton.Click += new System.EventHandler(this.MarksButton_Click);
            // 
            // ProfileButton
            // 
            this.ProfileButton.BackColor = System.Drawing.Color.Navy;
            this.ProfileButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.ProfileButton.FlatAppearance.BorderSize = 0;
            this.ProfileButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ProfileButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProfileButton.ForeColor = System.Drawing.Color.White;
            this.ProfileButton.Location = new System.Drawing.Point(0, 168);
            this.ProfileButton.Name = "ProfileButton";
            this.ProfileButton.Size = new System.Drawing.Size(196, 42);
            this.ProfileButton.TabIndex = 1;
            this.ProfileButton.Text = "     Students Profile";
            this.ProfileButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ProfileButton.UseVisualStyleBackColor = true;
            this.ProfileButton.Click += new System.EventHandler(this.ProfileButton_Click);
            // 
            // panel_slide
            // 
            this.panel_slide.AutoScroll = true;
            this.panel_slide.BackColor = System.Drawing.Color.Navy;
            this.panel_slide.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel_slide.Controls.Add(this.panel_AnnounceSubmenu);
            this.panel_slide.Controls.Add(this.button_Announcements);
            this.panel_slide.Controls.Add(this.pictureBox8);
            this.panel_slide.Controls.Add(this.pictureBox7);
            this.panel_slide.Controls.Add(this.panelmngstudentsubmenu);
            this.panel_slide.Controls.Add(this.Managestu_Button);
            this.panel_slide.Controls.Add(this.pictureBox5);
            this.panel_slide.Controls.Add(this.pictureBox6);
            this.panel_slide.Controls.Add(this.pictureBox4);
            this.panel_slide.Controls.Add(this.MeetscheduleButton);
            this.panel_slide.Controls.Add(this.MarksButton);
            this.panel_slide.Controls.Add(this.ProfileButton);
            this.panel_slide.Controls.Add(this.panel_home);
            this.panel_slide.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_slide.Location = new System.Drawing.Point(0, 0);
            this.panel_slide.Margin = new System.Windows.Forms.Padding(5);
            this.panel_slide.Name = "panel_slide";
            this.panel_slide.Size = new System.Drawing.Size(213, 504);
            this.panel_slide.TabIndex = 8;
            // 
            // panel_AnnounceSubmenu
            // 
            this.panel_AnnounceSubmenu.BackColor = System.Drawing.Color.SkyBlue;
            this.panel_AnnounceSubmenu.Controls.Add(this.button_viewall);
            this.panel_AnnounceSubmenu.Controls.Add(this.button_makeannouncement);
            this.panel_AnnounceSubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_AnnounceSubmenu.Location = new System.Drawing.Point(0, 504);
            this.panel_AnnounceSubmenu.Name = "panel_AnnounceSubmenu";
            this.panel_AnnounceSubmenu.Size = new System.Drawing.Size(196, 112);
            this.panel_AnnounceSubmenu.TabIndex = 19;
            // 
            // button_viewall
            // 
            this.button_viewall.BackColor = System.Drawing.Color.SkyBlue;
            this.button_viewall.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_viewall.FlatAppearance.BorderSize = 0;
            this.button_viewall.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_viewall.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_viewall.ForeColor = System.Drawing.Color.White;
            this.button_viewall.Location = new System.Drawing.Point(0, 50);
            this.button_viewall.Name = "button_viewall";
            this.button_viewall.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_viewall.Size = new System.Drawing.Size(196, 55);
            this.button_viewall.TabIndex = 1;
            this.button_viewall.Text = "View All Announcements";
            this.button_viewall.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_viewall.UseVisualStyleBackColor = false;
            this.button_viewall.Click += new System.EventHandler(this.button_viewall_Click);
            // 
            // button_makeannouncement
            // 
            this.button_makeannouncement.BackColor = System.Drawing.Color.SkyBlue;
            this.button_makeannouncement.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_makeannouncement.FlatAppearance.BorderSize = 0;
            this.button_makeannouncement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_makeannouncement.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_makeannouncement.ForeColor = System.Drawing.Color.White;
            this.button_makeannouncement.Location = new System.Drawing.Point(0, 0);
            this.button_makeannouncement.Name = "button_makeannouncement";
            this.button_makeannouncement.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_makeannouncement.Size = new System.Drawing.Size(196, 50);
            this.button_makeannouncement.TabIndex = 0;
            this.button_makeannouncement.Text = "Make Announcement";
            this.button_makeannouncement.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_makeannouncement.UseVisualStyleBackColor = false;
            this.button_makeannouncement.Click += new System.EventHandler(this.button_makeannouncement_Click);
            // 
            // button_Announcements
            // 
            this.button_Announcements.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Announcements.FlatAppearance.BorderSize = 0;
            this.button_Announcements.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Announcements.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Announcements.ForeColor = System.Drawing.Color.White;
            this.button_Announcements.Location = new System.Drawing.Point(0, 454);
            this.button_Announcements.Margin = new System.Windows.Forms.Padding(5);
            this.button_Announcements.Name = "button_Announcements";
            this.button_Announcements.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.button_Announcements.Size = new System.Drawing.Size(196, 50);
            this.button_Announcements.TabIndex = 18;
            this.button_Announcements.Text = "Announcements";
            this.button_Announcements.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Announcements.UseVisualStyleBackColor = true;
            this.button_Announcements.Click += new System.EventHandler(this.button_Announcements_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::deliverable_1.Properties.Resources.icons8_meeting_time_50;
            this.pictureBox8.Location = new System.Drawing.Point(143, 252);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(34, 34);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 17;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::deliverable_1.Properties.Resources.icons8_group_50;
            this.pictureBox7.Location = new System.Drawing.Point(143, 294);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(34, 34);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 17;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // panelmngstudentsubmenu
            // 
            this.panelmngstudentsubmenu.BackColor = System.Drawing.Color.SkyBlue;
            this.panelmngstudentsubmenu.Controls.Add(this.button_removeStudent);
            this.panelmngstudentsubmenu.Controls.Add(this.button_addstudent);
            this.panelmngstudentsubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelmngstudentsubmenu.Location = new System.Drawing.Point(0, 344);
            this.panelmngstudentsubmenu.Name = "panelmngstudentsubmenu";
            this.panelmngstudentsubmenu.Size = new System.Drawing.Size(196, 110);
            this.panelmngstudentsubmenu.TabIndex = 16;
            // 
            // button_removeStudent
            // 
            this.button_removeStudent.BackColor = System.Drawing.Color.SkyBlue;
            this.button_removeStudent.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_removeStudent.FlatAppearance.BorderSize = 0;
            this.button_removeStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_removeStudent.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_removeStudent.ForeColor = System.Drawing.Color.White;
            this.button_removeStudent.Location = new System.Drawing.Point(0, 50);
            this.button_removeStudent.Name = "button_removeStudent";
            this.button_removeStudent.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_removeStudent.Size = new System.Drawing.Size(196, 55);
            this.button_removeStudent.TabIndex = 1;
            this.button_removeStudent.Text = "Remove Student";
            this.button_removeStudent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_removeStudent.UseVisualStyleBackColor = false;
            this.button_removeStudent.Click += new System.EventHandler(this.button_removeStudent_Click);
            // 
            // button_addstudent
            // 
            this.button_addstudent.BackColor = System.Drawing.Color.SkyBlue;
            this.button_addstudent.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_addstudent.FlatAppearance.BorderSize = 0;
            this.button_addstudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_addstudent.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_addstudent.ForeColor = System.Drawing.Color.White;
            this.button_addstudent.Location = new System.Drawing.Point(0, 0);
            this.button_addstudent.Name = "button_addstudent";
            this.button_addstudent.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_addstudent.Size = new System.Drawing.Size(196, 50);
            this.button_addstudent.TabIndex = 0;
            this.button_addstudent.Text = "Add Student";
            this.button_addstudent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_addstudent.UseVisualStyleBackColor = false;
            this.button_addstudent.Click += new System.EventHandler(this.button_addstudent_Click);
            // 
            // Managestu_Button
            // 
            this.Managestu_Button.Dock = System.Windows.Forms.DockStyle.Top;
            this.Managestu_Button.FlatAppearance.BorderSize = 0;
            this.Managestu_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Managestu_Button.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Managestu_Button.ForeColor = System.Drawing.Color.White;
            this.Managestu_Button.Location = new System.Drawing.Point(0, 294);
            this.Managestu_Button.Margin = new System.Windows.Forms.Padding(5);
            this.Managestu_Button.Name = "Managestu_Button";
            this.Managestu_Button.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.Managestu_Button.Size = new System.Drawing.Size(196, 50);
            this.Managestu_Button.TabIndex = 15;
            this.Managestu_Button.Text = "Manage Students";
            this.Managestu_Button.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Managestu_Button.UseVisualStyleBackColor = true;
            this.Managestu_Button.Click += new System.EventHandler(this.Managestu_Button_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::deliverable_1.Properties.Resources.icons8_group_50;
            this.pictureBox5.Location = new System.Drawing.Point(143, 300);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(34, 37);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 11;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::deliverable_1.Properties.Resources.icons8_result_50;
            this.pictureBox6.Location = new System.Drawing.Point(143, 210);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(34, 34);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 11;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = global::deliverable_1.Properties.Resources.icons8_user_24;
            this.pictureBox4.Location = new System.Drawing.Point(143, 168);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(34, 34);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // panel_home
            // 
            this.panel_home.BackColor = System.Drawing.Color.Navy;
            this.panel_home.Controls.Add(this.pictureBox1);
            this.panel_home.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_home.Location = new System.Drawing.Point(0, 0);
            this.panel_home.Margin = new System.Windows.Forms.Padding(5);
            this.panel_home.Name = "panel_home";
            this.panel_home.Size = new System.Drawing.Size(196, 168);
            this.panel_home.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Navy;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = global::deliverable_1.Properties.Resources.home_button;
            this.pictureBox1.Location = new System.Drawing.Point(39, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 139);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button_LOGOUT
            // 
            this.button_LOGOUT.Location = new System.Drawing.Point(344, 79);
            this.button_LOGOUT.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button_LOGOUT.Name = "button_LOGOUT";
            this.button_LOGOUT.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.button_LOGOUT.Size = new System.Drawing.Size(97, 38);
            this.button_LOGOUT.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.button_LOGOUT.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.button_LOGOUT.StateCommon.Back.ColorAngle = 45F;
            this.button_LOGOUT.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.button_LOGOUT.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.button_LOGOUT.StateCommon.Border.ColorAngle = 45F;
            this.button_LOGOUT.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.button_LOGOUT.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.button_LOGOUT.StateCommon.Border.Rounding = 20;
            this.button_LOGOUT.StateCommon.Border.Width = 1;
            this.button_LOGOUT.StateCommon.Content.Image.Effect = ComponentFactory.Krypton.Toolkit.PaletteImageEffect.Normal;
            this.button_LOGOUT.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.button_LOGOUT.StateCommon.Content.ShortText.Color2 = System.Drawing.Color.White;
            this.button_LOGOUT.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_LOGOUT.TabIndex = 45;
            this.button_LOGOUT.Values.Text = "Logout";
            this.button_LOGOUT.Click += new System.EventHandler(this.button_LOGOUT_Click);
            // 
            // AdminHomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(1035, 504);
            this.Controls.Add(this.panel_main2);
            this.Controls.Add(this.panel_slide);
            this.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "AdminHomeForm";
            this.Text = "AdminHomeForm";
            this.panel_main2.ResumeLayout(false);
            this.panel_cover.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel_slide.ResumeLayout(false);
            this.panel_AnnounceSubmenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panelmngstudentsubmenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel_home.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_main2;
        private System.Windows.Forms.Panel panel_cover;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button MeetscheduleButton;
        private System.Windows.Forms.Button MarksButton;
        private System.Windows.Forms.Button ProfileButton;
        private System.Windows.Forms.Panel panel_slide;
        private System.Windows.Forms.Panel panel_home;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Managestu_Button;
        private System.Windows.Forms.Panel panelmngstudentsubmenu;
        private System.Windows.Forms.Button button_removeStudent;
        private System.Windows.Forms.Button button_addstudent;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button button_Announcements;
        private System.Windows.Forms.Panel panel_AnnounceSubmenu;
        private System.Windows.Forms.Button button_viewall;
        private System.Windows.Forms.Button button_makeannouncement;
        private ComponentFactory.Krypton.Toolkit.KryptonButton button_LOGOUT;
    }
}