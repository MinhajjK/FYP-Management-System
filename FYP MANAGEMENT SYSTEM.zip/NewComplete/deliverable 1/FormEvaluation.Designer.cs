﻿namespace deliverable_1
{
    partial class FormEvaluation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupIDbox = new System.Windows.Forms.TextBox();
            this.docmarksbox = new System.Windows.Forms.TextBox();
            this.midmarksbox = new System.Windows.Forms.TextBox();
            this.finalmarksbox = new System.Windows.Forms.TextBox();
            this.gradebox = new System.Windows.Forms.TextBox();
            this.Student1_IDlabel1 = new System.Windows.Forms.Label();
            this.s1IDBOX = new System.Windows.Forms.TextBox();
            this.Student3_IDlabel9 = new System.Windows.Forms.Label();
            this.s3IDBOX = new System.Windows.Forms.TextBox();
            this.Student1_IDlabel10 = new System.Windows.Forms.Label();
            this.s2IDBOX = new System.Windows.Forms.TextBox();
            this.cancelbutton1 = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonButton1 = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 51);
            this.panel1.TabIndex = 18;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::deliverable_1.Properties.Resources.icons8_result_50;
            this.pictureBox1.Location = new System.Drawing.Point(281, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Navy;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label7.Location = new System.Drawing.Point(337, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 26);
            this.label7.TabIndex = 0;
            this.label7.Text = "Evauations";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label2.Location = new System.Drawing.Point(213, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 19);
            this.label2.TabIndex = 19;
            this.label2.Text = "Group ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label3.Location = new System.Drawing.Point(213, 232);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 19);
            this.label3.TabIndex = 19;
            this.label3.Text = "Document Marks";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label4.Location = new System.Drawing.Point(213, 273);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 19);
            this.label4.TabIndex = 19;
            this.label4.Text = "Mid Marks";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label5.Location = new System.Drawing.Point(213, 314);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 19);
            this.label5.TabIndex = 19;
            this.label5.Text = "Final Marks";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label6.Location = new System.Drawing.Point(213, 348);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 19);
            this.label6.TabIndex = 19;
            this.label6.Text = "Grade";
            // 
            // groupIDbox
            // 
            this.groupIDbox.Location = new System.Drawing.Point(410, 78);
            this.groupIDbox.Name = "groupIDbox";
            this.groupIDbox.Size = new System.Drawing.Size(131, 20);
            this.groupIDbox.TabIndex = 20;
            // 
            // docmarksbox
            // 
            this.docmarksbox.Location = new System.Drawing.Point(410, 233);
            this.docmarksbox.Name = "docmarksbox";
            this.docmarksbox.Size = new System.Drawing.Size(131, 20);
            this.docmarksbox.TabIndex = 20;
            // 
            // midmarksbox
            // 
            this.midmarksbox.Location = new System.Drawing.Point(410, 272);
            this.midmarksbox.Name = "midmarksbox";
            this.midmarksbox.Size = new System.Drawing.Size(131, 20);
            this.midmarksbox.TabIndex = 20;
            // 
            // finalmarksbox
            // 
            this.finalmarksbox.Location = new System.Drawing.Point(410, 313);
            this.finalmarksbox.Name = "finalmarksbox";
            this.finalmarksbox.Size = new System.Drawing.Size(131, 20);
            this.finalmarksbox.TabIndex = 20;
            // 
            // gradebox
            // 
            this.gradebox.Location = new System.Drawing.Point(410, 347);
            this.gradebox.Name = "gradebox";
            this.gradebox.Size = new System.Drawing.Size(131, 20);
            this.gradebox.TabIndex = 20;
            // 
            // Student1_IDlabel1
            // 
            this.Student1_IDlabel1.AutoSize = true;
            this.Student1_IDlabel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Student1_IDlabel1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Student1_IDlabel1.Location = new System.Drawing.Point(213, 114);
            this.Student1_IDlabel1.Name = "Student1_IDlabel1";
            this.Student1_IDlabel1.Size = new System.Drawing.Size(94, 19);
            this.Student1_IDlabel1.TabIndex = 19;
            this.Student1_IDlabel1.Text = "Student1_ID";
            // 
            // s1IDBOX
            // 
            this.s1IDBOX.Location = new System.Drawing.Point(410, 115);
            this.s1IDBOX.Name = "s1IDBOX";
            this.s1IDBOX.Size = new System.Drawing.Size(131, 20);
            this.s1IDBOX.TabIndex = 20;
            // 
            // Student3_IDlabel9
            // 
            this.Student3_IDlabel9.AutoSize = true;
            this.Student3_IDlabel9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Student3_IDlabel9.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Student3_IDlabel9.Location = new System.Drawing.Point(213, 189);
            this.Student3_IDlabel9.Name = "Student3_IDlabel9";
            this.Student3_IDlabel9.Size = new System.Drawing.Size(94, 19);
            this.Student3_IDlabel9.TabIndex = 19;
            this.Student3_IDlabel9.Text = "Student3_ID";
            // 
            // s3IDBOX
            // 
            this.s3IDBOX.Location = new System.Drawing.Point(410, 188);
            this.s3IDBOX.Name = "s3IDBOX";
            this.s3IDBOX.Size = new System.Drawing.Size(131, 20);
            this.s3IDBOX.TabIndex = 20;
            // 
            // Student1_IDlabel10
            // 
            this.Student1_IDlabel10.AutoSize = true;
            this.Student1_IDlabel10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Student1_IDlabel10.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Student1_IDlabel10.Location = new System.Drawing.Point(213, 150);
            this.Student1_IDlabel10.Name = "Student1_IDlabel10";
            this.Student1_IDlabel10.Size = new System.Drawing.Size(94, 19);
            this.Student1_IDlabel10.TabIndex = 19;
            this.Student1_IDlabel10.Text = "Student2_ID";
            // 
            // s2IDBOX
            // 
            this.s2IDBOX.Location = new System.Drawing.Point(410, 151);
            this.s2IDBOX.Name = "s2IDBOX";
            this.s2IDBOX.Size = new System.Drawing.Size(131, 20);
            this.s2IDBOX.TabIndex = 20;
            // 
            // cancelbutton1
            // 
            this.cancelbutton1.Location = new System.Drawing.Point(278, 420);
            this.cancelbutton1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cancelbutton1.Name = "cancelbutton1";
            this.cancelbutton1.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.cancelbutton1.Size = new System.Drawing.Size(90, 35);
            this.cancelbutton1.StateCommon.Back.Color1 = System.Drawing.Color.Brown;
            this.cancelbutton1.StateCommon.Back.Color2 = System.Drawing.Color.Firebrick;
            this.cancelbutton1.StateCommon.Back.ColorAngle = 45F;
            this.cancelbutton1.StateCommon.Border.Color1 = System.Drawing.Color.Red;
            this.cancelbutton1.StateCommon.Border.Color2 = System.Drawing.Color.Red;
            this.cancelbutton1.StateCommon.Border.ColorAngle = 45F;
            this.cancelbutton1.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.cancelbutton1.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.cancelbutton1.StateCommon.Border.Rounding = 20;
            this.cancelbutton1.StateCommon.Border.Width = 1;
            this.cancelbutton1.StateCommon.Content.Image.Effect = ComponentFactory.Krypton.Toolkit.PaletteImageEffect.Normal;
            this.cancelbutton1.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.cancelbutton1.StateCommon.Content.ShortText.Color2 = System.Drawing.Color.White;
            this.cancelbutton1.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelbutton1.TabIndex = 48;
            this.cancelbutton1.Values.Text = "Cancel";
            this.cancelbutton1.Click += new System.EventHandler(this.cancelbutton1_Click);
            // 
            // kryptonButton1
            // 
            this.kryptonButton1.Location = new System.Drawing.Point(372, 420);
            this.kryptonButton1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.kryptonButton1.Name = "kryptonButton1";
            this.kryptonButton1.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.kryptonButton1.Size = new System.Drawing.Size(90, 35);
            this.kryptonButton1.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.kryptonButton1.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.kryptonButton1.StateCommon.Back.ColorAngle = 45F;
            this.kryptonButton1.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.kryptonButton1.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.kryptonButton1.StateCommon.Border.ColorAngle = 45F;
            this.kryptonButton1.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton1.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.kryptonButton1.StateCommon.Border.Rounding = 20;
            this.kryptonButton1.StateCommon.Border.Width = 1;
            this.kryptonButton1.StateCommon.Content.Image.Effect = ComponentFactory.Krypton.Toolkit.PaletteImageEffect.Normal;
            this.kryptonButton1.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.kryptonButton1.StateCommon.Content.ShortText.Color2 = System.Drawing.Color.White;
            this.kryptonButton1.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton1.TabIndex = 47;
            this.kryptonButton1.Values.Text = "Add";
            this.kryptonButton1.Click += new System.EventHandler(this.kryptonButton1_Click);
            // 
            // FormEvaluation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(800, 485);
            this.Controls.Add(this.cancelbutton1);
            this.Controls.Add(this.kryptonButton1);
            this.Controls.Add(this.gradebox);
            this.Controls.Add(this.finalmarksbox);
            this.Controls.Add(this.midmarksbox);
            this.Controls.Add(this.docmarksbox);
            this.Controls.Add(this.s3IDBOX);
            this.Controls.Add(this.s2IDBOX);
            this.Controls.Add(this.s1IDBOX);
            this.Controls.Add(this.groupIDbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Student3_IDlabel9);
            this.Controls.Add(this.Student1_IDlabel10);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Student1_IDlabel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FormEvaluation";
            this.Text = "FormEvaluation";
            this.Load += new System.EventHandler(this.FormEvaluation_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox groupIDbox;
        private System.Windows.Forms.TextBox docmarksbox;
        private System.Windows.Forms.TextBox midmarksbox;
        private System.Windows.Forms.TextBox finalmarksbox;
        private System.Windows.Forms.TextBox gradebox;
        private System.Windows.Forms.Label Student1_IDlabel1;
        private System.Windows.Forms.TextBox s1IDBOX;
        private System.Windows.Forms.Label Student3_IDlabel9;
        private System.Windows.Forms.TextBox s3IDBOX;
        private System.Windows.Forms.Label Student1_IDlabel10;
        private System.Windows.Forms.TextBox s2IDBOX;
        private System.Windows.Forms.PictureBox pictureBox1;
        private ComponentFactory.Krypton.Toolkit.KryptonButton cancelbutton1;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButton1;
    }
}