﻿namespace deliverable_1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.STUDENTID1 = new System.Windows.Forms.TextBox();
            this.STUDENTID3 = new System.Windows.Forms.TextBox();
            this.STUDENTID2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.PROJECTDESCRIPTION = new System.Windows.Forms.TextBox();
            this.GROUPID = new System.Windows.Forms.TextBox();
            this.PROJECTNAME = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.GROUPNAME = new System.Windows.Forms.TextBox();
            this.cancelbutton1 = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonButton1 = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // STUDENTID1
            // 
            this.STUDENTID1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.STUDENTID1.Location = new System.Drawing.Point(610, 106);
            this.STUDENTID1.Name = "STUDENTID1";
            this.STUDENTID1.Size = new System.Drawing.Size(156, 20);
            this.STUDENTID1.TabIndex = 31;
            this.STUDENTID1.TextChanged += new System.EventHandler(this.MEMBERNAME1_TextChanged);
            // 
            // STUDENTID3
            // 
            this.STUDENTID3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.STUDENTID3.Location = new System.Drawing.Point(610, 174);
            this.STUDENTID3.Name = "STUDENTID3";
            this.STUDENTID3.Size = new System.Drawing.Size(156, 20);
            this.STUDENTID3.TabIndex = 31;
            this.STUDENTID3.TextChanged += new System.EventHandler(this.MEMBERNAME3_TextChanged);
            // 
            // STUDENTID2
            // 
            this.STUDENTID2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.STUDENTID2.Location = new System.Drawing.Point(610, 142);
            this.STUDENTID2.Name = "STUDENTID2";
            this.STUDENTID2.Size = new System.Drawing.Size(156, 20);
            this.STUDENTID2.TabIndex = 31;
            this.STUDENTID2.TextChanged += new System.EventHandler(this.MEMBERNAME2_TextChanged);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label2.Location = new System.Drawing.Point(473, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 19);
            this.label2.TabIndex = 30;
            this.label2.Text = "Student1 ID";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label3.Location = new System.Drawing.Point(473, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 19);
            this.label3.TabIndex = 30;
            this.label3.Text = "Student3 ID";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label6.Location = new System.Drawing.Point(473, 142);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 19);
            this.label6.TabIndex = 30;
            this.label6.Text = "Student2 ID";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // PROJECTDESCRIPTION
            // 
            this.PROJECTDESCRIPTION.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PROJECTDESCRIPTION.Location = new System.Drawing.Point(142, 232);
            this.PROJECTDESCRIPTION.Multiline = true;
            this.PROJECTDESCRIPTION.Name = "PROJECTDESCRIPTION";
            this.PROJECTDESCRIPTION.Size = new System.Drawing.Size(624, 50);
            this.PROJECTDESCRIPTION.TabIndex = 25;
            this.PROJECTDESCRIPTION.TextChanged += new System.EventHandler(this.PROJECTDESCRIPTION_TextChanged);
            // 
            // GROUPID
            // 
            this.GROUPID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.GROUPID.Location = new System.Drawing.Point(142, 143);
            this.GROUPID.Name = "GROUPID";
            this.GROUPID.Size = new System.Drawing.Size(140, 20);
            this.GROUPID.TabIndex = 21;
            this.GROUPID.TextChanged += new System.EventHandler(this.GROUPID_TextChanged);
            // 
            // PROJECTNAME
            // 
            this.PROJECTNAME.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PROJECTNAME.Location = new System.Drawing.Point(142, 175);
            this.PROJECTNAME.Name = "PROJECTNAME";
            this.PROJECTNAME.Size = new System.Drawing.Size(140, 20);
            this.PROJECTNAME.TabIndex = 21;
            this.PROJECTNAME.TextChanged += new System.EventHandler(this.PROJECTNAME_TextChanged);
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label8.Location = new System.Drawing.Point(38, 143);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 19);
            this.label8.TabIndex = 20;
            this.label8.Text = "Group ID";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label5.Location = new System.Drawing.Point(38, 210);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 19);
            this.label5.TabIndex = 20;
            this.label5.Text = "Project Description";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label4.Location = new System.Drawing.Point(38, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 19);
            this.label4.TabIndex = 20;
            this.label4.Text = "Project Name";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(38, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 19);
            this.label1.TabIndex = 15;
            this.label1.Text = "Group Name ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 51);
            this.panel1.TabIndex = 17;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::deliverable_1.Properties.Resources.icons8_group_50;
            this.pictureBox1.Location = new System.Drawing.Point(294, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Navy;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(350, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(180, 26);
            this.label7.TabIndex = 0;
            this.label7.Text = "Register Groups";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SkyBlue;
            this.panel2.Controls.Add(this.cancelbutton1);
            this.panel2.Controls.Add(this.kryptonButton1);
            this.panel2.Controls.Add(this.STUDENTID1);
            this.panel2.Controls.Add(this.STUDENTID3);
            this.panel2.Controls.Add(this.STUDENTID2);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.PROJECTDESCRIPTION);
            this.panel2.Controls.Add(this.GROUPID);
            this.panel2.Controls.Add(this.PROJECTNAME);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.GROUPNAME);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 57);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 428);
            this.panel2.TabIndex = 18;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // GROUPNAME
            // 
            this.GROUPNAME.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.GROUPNAME.Location = new System.Drawing.Point(142, 107);
            this.GROUPNAME.Name = "GROUPNAME";
            this.GROUPNAME.Size = new System.Drawing.Size(140, 20);
            this.GROUPNAME.TabIndex = 18;
            this.GROUPNAME.TextChanged += new System.EventHandler(this.GROUPNAME_TextChanged);
            // 
            // cancelbutton1
            // 
            this.cancelbutton1.Location = new System.Drawing.Point(280, 358);
            this.cancelbutton1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cancelbutton1.Name = "cancelbutton1";
            this.cancelbutton1.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.cancelbutton1.Size = new System.Drawing.Size(90, 35);
            this.cancelbutton1.StateCommon.Back.Color1 = System.Drawing.Color.Brown;
            this.cancelbutton1.StateCommon.Back.Color2 = System.Drawing.Color.Firebrick;
            this.cancelbutton1.StateCommon.Back.ColorAngle = 45F;
            this.cancelbutton1.StateCommon.Border.Color1 = System.Drawing.Color.Red;
            this.cancelbutton1.StateCommon.Border.Color2 = System.Drawing.Color.Red;
            this.cancelbutton1.StateCommon.Border.ColorAngle = 45F;
            this.cancelbutton1.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.cancelbutton1.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.cancelbutton1.StateCommon.Border.Rounding = 20;
            this.cancelbutton1.StateCommon.Border.Width = 1;
            this.cancelbutton1.StateCommon.Content.Image.Effect = ComponentFactory.Krypton.Toolkit.PaletteImageEffect.Normal;
            this.cancelbutton1.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.cancelbutton1.StateCommon.Content.ShortText.Color2 = System.Drawing.Color.White;
            this.cancelbutton1.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelbutton1.TabIndex = 46;
            this.cancelbutton1.Values.Text = "Cancel";
            this.cancelbutton1.Click += new System.EventHandler(this.cancelbutton1_Click);
            // 
            // kryptonButton1
            // 
            this.kryptonButton1.Location = new System.Drawing.Point(374, 358);
            this.kryptonButton1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.kryptonButton1.Name = "kryptonButton1";
            this.kryptonButton1.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.kryptonButton1.Size = new System.Drawing.Size(90, 35);
            this.kryptonButton1.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.kryptonButton1.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.kryptonButton1.StateCommon.Back.ColorAngle = 45F;
            this.kryptonButton1.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.kryptonButton1.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.kryptonButton1.StateCommon.Border.ColorAngle = 45F;
            this.kryptonButton1.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton1.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.kryptonButton1.StateCommon.Border.Rounding = 20;
            this.kryptonButton1.StateCommon.Border.Width = 1;
            this.kryptonButton1.StateCommon.Content.Image.Effect = ComponentFactory.Krypton.Toolkit.PaletteImageEffect.Normal;
            this.kryptonButton1.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.kryptonButton1.StateCommon.Content.ShortText.Color2 = System.Drawing.Color.White;
            this.kryptonButton1.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton1.TabIndex = 45;
            this.kryptonButton1.Values.Text = "Add";
            this.kryptonButton1.Click += new System.EventHandler(this.kryptonButton1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 485);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "Form3";
            this.Text = "Form3";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox STUDENTID1;
        private System.Windows.Forms.TextBox STUDENTID3;
        private System.Windows.Forms.TextBox STUDENTID2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox PROJECTDESCRIPTION;
        private System.Windows.Forms.TextBox GROUPID;
        private System.Windows.Forms.TextBox PROJECTNAME;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox GROUPNAME;
        private System.Windows.Forms.PictureBox pictureBox1;
        private ComponentFactory.Krypton.Toolkit.KryptonButton cancelbutton1;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButton1;
    }
}