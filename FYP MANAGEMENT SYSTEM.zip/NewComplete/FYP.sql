
USE myDB;
CREATE TABLE RegisterGroups (
    GroupName VARCHAR(255),
    GroupID VARCHAR(255) PRIMARY KEY,
    ProjectName VARCHAR(255),
    Student1_ID VARCHAR(255) UNIQUE,
    Student2_ID VARCHAR(255) UNIQUE,
    Student3_ID VARCHAR(255) UNIQUE,
    ProjectDescription VARCHAR(255)
);
INSERT INTO RegisterGroups (GroupName, GroupID, ProjectName, Student1_ID, Student2_ID, Student3_ID, ProjectDescription) 
VALUES 
('Alpha', 'GID200', 'Anigen', '22i3456', '21i9876', '20i2567', 'A project to develop a new vaccine'),
('Beta', 'GID201', 'TechSolutions', '19i0518', '18i7823', '17i3928', 'Creating a software for inventory management'),
('Gamma', 'GID202', 'EcoGreen', '16i9823', '15i6472', '14i2736', 'Researching sustainable energy solutions'),
('Delta', 'GID203', 'BioMed', '13i8947', '12i5762', '11i2673', 'Studying the effects of genetic mutations'),
('Epsilon', 'GID204', 'SmartHome', '10i5473', '9i2456', '8i9834', 'Building IoT devices for home automation');

DROP TABLE RegisterGroups;




	SELECT * FROM RegisterGroups;

	Drop table ScheduleMeeting;
	CREATE TABLE ScheduleMeeting (
	MeetingID INT IDENTITY(1,1) PRIMARY KEY,
    GroupID VARCHAR(255),
	Student_ID VARCHAR(255),
    MeetingDate DATE,
    MeetingTime TIME,
    MeetingAgenda VARCHAR(500)
	FOREIGN KEY (GroupID) REFERENCES RegisterGroups(GroupID)
	
);

INSERT INTO ScheduleMeeting (GroupID, MeetingDate, MeetingTime, MeetingAgenda)
VALUES 
    ('GID200', '2024-03-21', '10:00:00', 'Discuss project progress'),
    ('GID201', '2024-03-22', '14:30:00', 'Review project requirements'),
    ('GID202', '2024-03-23', '09:00:00', 'Plan next sprint tasks'),
    ('GID203', '2024-03-24', '11:00:00', 'Brainstorm new project ideas'),
    ('GID204', '2024-03-25', '13:00:00', 'Training session o2n new tools');

	SELECT * FROM ScheduleMeeting ;


	CREATE TABLE Supervisor (
    SupervisorID VARCHAR(100) PRIMARY KEY NOT NULL,
    Password VARCHAR(255) NOT NULL
);



INSERT INTO Supervisor (SupervisorID, Password) VALUES 
('sirbilal100', 'Supervisor100@'),
('drkashifmunir200', 'Supervisor200@'),
('drakhtarjamil300', 'Supervisor300@'),
('draleem400', 'Supervisor400@'),
('drajaz500', 'Supervisor500@'),
('drahmedraza600', 'Supervisor600@');


use myDB;

 select * from Supervisor;



 select * from RegisterGroups;

 

CREATE TABLE Evaluation (
    EvaluationID INT IDENTITY(1,1) PRIMARY KEY,
    Student1_ID VARCHAR(255),
    Student2_ID VARCHAR(255),
    Student3_ID VARCHAR(255),
    GroupID VARCHAR(255),
    Document_Marks DECIMAL(5, 2),
    Mid_Marks DECIMAL(5, 2),
    Final_Marks DECIMAL(5, 2),
    Grade CHAR(1),
    FOREIGN KEY (GroupID) REFERENCES RegisterGroups(GroupID)
);

INSERT INTO Evaluation (GroupID, Student1_ID, Student2_ID, Student3_ID, Document_Marks, Mid_Marks, Final_Marks, Grade)
VALUES 
('GID200', '22i3456', '21i9876', '20i2567', 20.50, 22.50, 45.00, 'B'),
('GID201', '19i0518', '18i7823', '17i3928', 18.75, 20.00, 40.00, 'C'),
('GID202', '16i9823', '15i6472', '14i2736', 23.75, 24.00, 47.50, 'A'),
('GID203', '13i8947', '12i5762', '11i2673', 15.25, 17.50, 38.75, 'D'),
('GID204', '10i5473', '9i2456', '8i9834', 24.00, 23.75, 47.50, 'A');


select * from Evaluation;



CREATE TABLE MakeAnnouncements (
    AnnouncementID INT IDENTITY(1,1) PRIMARY KEY,
    SupervisorID VARCHAR(255),
    AnnouncementDate DATETIME,
    Title VARCHAR(255),
    Content TEXT,
    CreatedDate DATETIME DEFAULT GETDATE()
);

INSERT INTO MakeAnnouncements (SupervisorID, AnnouncementDate, Title, Content)
VALUES 
('drbilal01', GETDATE(), 'New Policy Announcement', 'Announcing a new policy update for all employees. Please review.'),
('drkashifmunir02', GETDATE(), 'Meeting Reminder', 'Reminder: Staff meeting scheduled for tomorrow at 10:00 AM in the conference room.'),
('drakhtarjamil03', GETDATE(), 'Important Update', 'Update: Changes to the project timeline. Please see details.'),
('draleem04', GETDATE(), 'Training Session Announcement', 'Training session on new software tools. Register now.'),
('drajaz05', GETDATE(), 'Project Deadline Extension', 'Extension: Deadline for project submission extended by one week.');

select * from MakeAnnouncements;

-------------------------------Student Module-------------------------------------------------------------
use myDB;

select * from RegisterGroups 

CREATE TABLE Students (
    StudentID VARCHAR(255) PRIMARY KEY,
    GroupID VARCHAR(255),
    StudentName VARCHAR(255),
    Degree VARCHAR(255),
    Email VARCHAR(255),
    ContactNumber VARCHAR(20),
    DateOfBirth DATE,
    City VARCHAR(255),
    Password VARCHAR(255), -- Add the password field
    FOREIGN KEY (GroupID) REFERENCES RegisterGroups(GroupID)
);

INSERT INTO Students (StudentID, GroupID, StudentName, Degree, Email, ContactNumber, DateOfBirth, City, Password)
VALUES
('22i3456', 'GID200', 'Ali Khan', 'Computer Science', 'ali.khan@example.com', '1234567890', '2000-05-15', 'Karachi', 'Password12!'),
('21i9876', 'GID200', 'Sara Ahmed', 'Electrical Engineering', 'sara.ahmed@example.com', '9876543210', '2001-02-28', 'Lahore', 'Password34@'),
('20i2567', 'GID200', 'Amir Malik', 'Mechanical Engineering', 'amir.malik@example.com', '2345678901', '2000-08-10', 'Islamabad', 'Password56#'),
('19i0518', 'GID201', 'Asim Sharif', 'Computer Science', 'asimsharif603@gmail.com', '3456789012', '2001-06-16', 'Mansehra', 'Password20@'),
('18i7823', 'GID201', 'Usman Ali', 'Computer Science', 'usman.ali@example.com', '4567890123', '2000-03-05', 'Karachi', 'Password90%'),
('17i3928', 'GID201', 'Ayesha Siddiqui', 'Software Engineering', 'ayesha.siddiqui@example.com', '5678901234', '1999-07-12', 'Islamabad', 'Password100$');

select * from Students;

CREATE TABLE ChatMessages (
    MessageID INT IDENTITY(1,1) PRIMARY KEY,
    StudentID NVARCHAR(4000) ,
    SupervisorID NVARCHAR(4000) ,
    Message NVARCHAR(MAX) NOT NULL,
    Timestamp DATETIME NOT NULL DEFAULT GETDATE()
);
use myDB;
drop table ChatMessages; 
select * from ChatMessages;
-------------------------------------------------------------------------------------------------------------------------------


CREATE TABLE Admin (
    AdminID VARCHAR(100) PRIMARY KEY NOT NULL,
    Password VARCHAR(255) NOT NULL
);


INSERT INTO Admin (AdminID, Password) 
VALUES
('admin100', 'Adminpass100@'),
('admin200', 'Adminpass200@'),
('admin300', 'Adminpass300@'),
('admin400', 'Adminpass400@'),
('admin500', 'Adminpass500@');
